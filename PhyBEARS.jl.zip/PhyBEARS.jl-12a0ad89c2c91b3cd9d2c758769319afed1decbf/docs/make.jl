using Documenter, PhyBEARS

makedocs(modules = [PhyBEARS], sitename = "PhyBEARS.jl")

deploydocs(repo = "github.com/nmatzke/PhyBEARS.jl.git")
