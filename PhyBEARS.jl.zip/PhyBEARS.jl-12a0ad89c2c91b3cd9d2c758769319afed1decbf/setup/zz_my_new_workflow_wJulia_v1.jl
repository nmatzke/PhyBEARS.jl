## Julia startup advice:
## https://medium.com/@Jernfrost/my-new-workflow-with-julia-1-0-99711103d97c
## startup.jl 
#

# 
push!(LOAD_PATH, "$(homedir())/GitHub/")
