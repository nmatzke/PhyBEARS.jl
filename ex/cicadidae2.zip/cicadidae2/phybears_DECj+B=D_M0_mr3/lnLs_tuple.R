input_tuple = list()
input_tuple$total_calctime_in_sec = 0.955
input_tuple$iteration_number = 16
input_tuple$Julia_sum_lq = -975.2174816868712
input_tuple$rootstates_lnL = -11.916304429056959
input_tuple$Julia_total_lnLs1 = -987.1337861159282
input_tuple$bgb_lnL = -294.04209195345925
input_tuple$total_loglikelihood = -294.04209195345925
