input_tuple = list()
input_tuple$total_calctime_in_sec = 0.67
input_tuple$iteration_number = 16
input_tuple$Julia_sum_lq = -945.0402604927801
input_tuple$rootstates_lnL = -8.447010505321131
input_tuple$Julia_total_lnLs1 = -953.4872709981013
input_tuple$bgb_lnL = -261.5706924042445
input_tuple$total_loglikelihood = -261.5706924042445
