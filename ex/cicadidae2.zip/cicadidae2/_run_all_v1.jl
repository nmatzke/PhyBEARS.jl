cd("/GitHub/PhyBEARS.jl/ex/cicadidae2/phybears_DEC_M0_mr3/")
include("/GitHub/PhyBEARS.jl/ex/cicadidae2/phybears_DEC_M0_mr3/phybears_M0_mr3_DEC_v2.jl")

cd("/GitHub/PhyBEARS.jl/ex/cicadidae2/phybears_DECj_M0_mr3/")
include("/GitHub/PhyBEARS.jl/ex/cicadidae2/phybears_DECj_M0_mr3/phybears_M0_mr3_DEC+J_v2.jl")

cd("/GitHub/PhyBEARS.jl/ex/cicadidae2/phybears_DEC+BD_M0_mr3/")
include("/GitHub/PhyBEARS.jl/ex/cicadidae2/phybears_DEC+BD_M0_mr3/phybears_M0_mr3_DEC+BD_v2.jl")

cd("/GitHub/PhyBEARS.jl/ex/cicadidae2/phybears_DECj+B=D_M0_mr3/")
include("/GitHub/PhyBEARS.jl/ex/cicadidae2/phybears_DECj+BD_M0_mr3/phybears_M0_mr3_DEC+J_BD_v2.jl")

cd("/GitHub/PhyBEARS.jl/ex/cicadidae2/phybears_DEC+B=D_M0_mr3/")
include("/GitHub/PhyBEARS.jl/ex/cicadidae2/phybears_DEC+B=D_M0_mr3/phybears_M0_mr3_DEC+B=D_v2.jl")

cd("/GitHub/PhyBEARS.jl/ex/cicadidae2/phybears_DECj+B=D_M0_mr3/")
include("/GitHub/PhyBEARS.jl/ex/cicadidae2/phybears_DECj+B=D_M0_mr3/phybears_M0_mr3_DEC+J_B=D_v2.jl")


