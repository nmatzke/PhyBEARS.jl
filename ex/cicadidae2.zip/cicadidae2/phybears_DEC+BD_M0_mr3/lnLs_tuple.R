input_tuple = list()
input_tuple$total_calctime_in_sec = 0.494
input_tuple$iteration_number = 16
input_tuple$Julia_sum_lq = -986.973759282248
input_tuple$rootstates_lnL = -11.56515641930104
input_tuple$Julia_total_lnLs1 = -998.5389157015491
input_tuple$bgb_lnL = -306.0836203772899
input_tuple$total_loglikelihood = -306.0836203772899
